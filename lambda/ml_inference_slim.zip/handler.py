import json
import boto3
import pickle
import os
from datetime import datetime

# Initialize S3 client for model loading
s3 = boto3.client('s3')
MODEL_BUCKET = os.environ['MODEL_BUCKET']
MODEL_KEY = 'models/forgetting_curve_v1.pkl'

# Global model variable for reuse across invocations
model = None

# Load ML model from S3 on cold start
# Model is cached for subsequent invocations (warm starts)
def load_model():
    """Download and load model from S3"""
    global model
    if model is None:
        print(f"Loading model from s3://{MODEL_BUCKET}/{MODEL_KEY}")
        response = s3.get_object(Bucket=MODEL_BUCKET, Key=MODEL_KEY)
        model_bytes = response['Body'].read()
        model = pickle.loads(model_bytes)
        print("Model loaded successfully")
    return model

# Lambda handler - processes ML prediction requests
# Input: card metadata (days since review, review count, difficulty)
# Output: recall probability and optimal review timing
def lambda_handler(event, context):
    """
    Lambda handler for ML predictions
    Expected input:
    {
      "card_id": 123,  # INTEGER
      "days_since_review": 5,
      "review_count": 3,
      "difficulty_score": 0.6
    }
    """
    try:
        # Parse input from API Gateway or direct invocation
        body = json.loads(event.get('body', '{}')) if isinstance(event.get('body'), str) else event

        # Extract card metadata
        card_id = body.get('card_id')
        days_since_review = body['days_since_review']
        review_count = body['review_count']
        difficulty_score = body['difficulty_score']

        print(f"Prediction request: card_id={card_id}, days={days_since_review}, reviews={review_count}, difficulty={difficulty_score}")

        # Load model and make prediction
        model = load_model()
        recall_probability = model.predict_recall_probability(
            days_since_review, review_count, difficulty_score
        )

        # Calculate optimal review time
        optimal_days = model.get_optimal_review_time(recall_probability)

        print(f"Prediction: recall_prob={recall_probability:.2f}, optimal_days={optimal_days}")

        # Return prediction results
        return {
            'statusCode': 200,
            'body': json.dumps({
                'card_id': card_id,
                'recall_probability': float(recall_probability),
                'optimal_review_days': int(optimal_days),
                'recommendation': 'Review today!' if optimal_days == 0 else 'Review tomorrow',
                'model_version': 'v1',
                'timestamp': str(datetime.now())
            })
        }

    except KeyError as e:
        return {
            'statusCode': 400,
            'body': json.dumps({
                'error': f'Missing required field: {str(e)}'
            })
        }
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e)
            })
        }
